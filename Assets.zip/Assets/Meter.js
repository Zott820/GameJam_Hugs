﻿#pragma strict

class Meter extends MonoBehaviour{

	var score     : double;
	var minReq    : double;
	var limit     : double;
	var meterData : Hashtable;
	function Cal(p : PlayerScript, npc : NPCScript) {
		/* if diff is higher than buffer:
		 *   + regular point * mod (either crit or penalty)
		 * else:
		 *   + regular point
		 * then check the score against the limit
		 */
		if (Mathf.Abs(p.cha - npc.cha) > npc.buffer) {
			score += 2 * npc.score * Mod(p, npc);
		} else {
			score += npc.score;
		}
		CheckLimit();
	}
	function Mod(p : PlayerScript, npc : NPCScript) : float {
		/* if player cha is lower than npc:
		 *   crit    ->  2.0
		 * else:
		 *   penalty -> -1.0
		 */
		return (p.cha > npc.cha) ? -1.0 : 2.0;
	}
	function Complete() : int {
		/* if score < minReq:
		 *   fail    -> 0
		 * else if score != limit:
		 *   success -> 1
		 * else:
		 *   crit    -> 2
		 */
		return (score < minReq) ? 0 : ((score != limit) ? 1 : 2);
	}
	function CheckLimit() {
		/* if score is beyond limit:
		 *   set score as limit
		 */
		if (score > limit) {
			score = limit;
		}
	}
	
	function Start () {
		this.gameObject.tag = "Meter";
		meterData = this.GetComponentInParent(SceneMap).data["meter"] as Hashtable;
		score = parseFloat(meterData["score"] as String);
		minReq = parseFloat(meterData["minReq"] as String );
		limit = parseFloat(meterData["limit"] as String);
		
	}

	function Update () {

	}
}