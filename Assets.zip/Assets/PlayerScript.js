﻿#pragma strict

class PlayerScript extends MonoBehaviour {
	var currentState : int;
	var playerData : Hashtable;
	var cha : int;
	var movDirection : int;
	var device : UnityEngine.DeviceType;
	var anim : UnityEngine.Animator;

	var up0    : UnityEngine.KeyCode = UnityEngine.KeyCode.W;
	var left0  : UnityEngine.KeyCode = UnityEngine.KeyCode.A;
	var down0  : UnityEngine.KeyCode = UnityEngine.KeyCode.S;
	var right0 : UnityEngine.KeyCode = UnityEngine.KeyCode.D;
	var up1    : UnityEngine.KeyCode = UnityEngine.KeyCode.UpArrow;
	var left1  : UnityEngine.KeyCode = UnityEngine.KeyCode.LeftArrow;
	var down1  : UnityEngine.KeyCode = UnityEngine.KeyCode.DownArrow;
	var right1 : UnityEngine.KeyCode = UnityEngine.KeyCode.RightArrow;
	var space  : UnityEngine.KeyCode = UnityEngine.KeyCode.Space;

	var u : boolean;
	var l : boolean;
	var d : boolean;
	var r : boolean;
	var s : boolean;

	function Start() {
		GameObject.FindWithTag( "MainCamera" ).transform.parent = this.transform;
		SetResources();
		SetParams();
	}
	function Update() {
		GetPlayerInput();
		ExecutePlayerInput();

	}
	function ExecutePlayerInput() {
		SetPlayerDirection();
		SetPlayerAction();
	}
	/*
	▒███████▒████████▒▒████████
	██▒▒▒▒▒▒▒██▒▒▒▒▒▒▒▒▒▒▒██▒▒▒
	██▒▒▒██▒▒████████▒▒▒▒▒██▒▒▒
	▒██▒▒▒██▒██▒▒▒▒▒▒▒▒▒▒▒██▒▒▒
	▒▒█████▒▒████████▒▒▒▒▒██▒▒▒
	*/
	function GetPlayerInput() {
		u = (UnityEngine.Input.GetKey(up0) || UnityEngine.Input.GetKey(up1));
		l = (UnityEngine.Input.GetKey(left0) || UnityEngine.Input.GetKey(left1));
		d = (UnityEngine.Input.GetKey(down0) || UnityEngine.Input.GetKey(down1));
		r = (UnityEngine.Input.GetKey(right0) || UnityEngine.Input.GetKey(right1));
		s = UnityEngine.Input.GetKey(space);
	}
	/*
	▒██████▒▒████████▒████████
	██▒▒▒▒▒▒▒██▒▒▒▒▒▒▒▒▒▒██▒▒▒
	▒██████▒▒████████▒▒▒▒██▒▒▒
	▒▒▒▒▒▒██▒██▒▒▒▒▒▒▒▒▒▒██▒▒▒
	▒██████▒▒████████▒▒▒▒██▒▒▒
	*/
	function SetPlayerDirection() {
			movDirection = u ? 
			(d ? (l ? (r ? 0 : 4) : (r ? 6 : 0)) : (l ? (r ? 2 : 1) : (r ? (l ? 2 : 3) : 2))) : 
			(l ? (r ? (d ? 8 : 0) : (d ? 7 : 4)) : (r ? (d ? 9 : 6) : (d ? 8 : 0)));
		switch (movDirection) {
		case 1:
			transform.localEulerAngles = new Vector3(0,0,45);
			break;
		case 2:
			transform.localEulerAngles = new Vector3(0,0,0);
			break;
		case 3:
			transform.localEulerAngles = new Vector3(0,0,-45);
			break;
		case 4:
			transform.localEulerAngles = new Vector3(0,0,90);
			break;
		case 6:
			transform.localEulerAngles = new Vector3(0,0,-90);
			break;
		case 7:
			transform.localEulerAngles = new Vector3(0,0,135);
			break;
		case 8:
			transform.localEulerAngles = new Vector3(0,0,180);
			break;
		case 9:
			transform.localEulerAngles = new Vector3(0,0,-135);
			break;
		case 0:
			break;
		}
	}
	function SetPlayerAction() {
		if (u) {
			transform.Translate(-1,0,0);
		}
		if (l) {
			transform.Translate(0,-1,0);
		}
		if (d) {
			transform.Translate(1,0,0);
		}
		if (r) {
			transform.Translate(0,1,0);
		}
		if (s) {
			// do hug
		}
	}
  	function SetResources() {
  		playerData = transform.parent.GetComponent(SceneMap).data["Player"];
  		device = SystemInfo.deviceType;
  		anim = this.GetComponent(Animator);
  	}
	function SetParams() {
		cha = parseInt(playerData["cha"] as String);
	}
}