﻿#pragma strict

class NPCScript extends MonoBehaviour {
	var currentState : int = 0;
	var playerData : Hashtable;
	var cha : int;
	var score : int;
	var buffer : int;
	var movDirection : int;
	var device : UnityEngine.DeviceType;
	
	
	var u : boolean;
	var l : boolean;
	var d : boolean;
	var r : boolean;

	// Markov Model for NPC Movement Probabilities
	var MOVE_STATE_PROBABILITY : float = 0.80; // 90 % chance to move 
	var STAY_STATE_PROBABILITY : float = 0.95; // 90 % to stay in current location
	var STATE_MOVING : int = 0;
	var STATE_STOPPED : int = 1;
	var Timer : float = 0.0;
	function Update(){
	
		Move();
	}
	
	function Move() {
	 	Timer += Time.deltaTime;
	 	System.Console.Write(Timer.ToString());
		if (Timer > 0.3){
			System.Console.Write("asdf");
			if( currentState == STATE_MOVING && Random.value <=  MOVE_STATE_PROBABILITY ){
				this.currentState = STATE_MOVING;
			}
			else if( currentState == STATE_MOVING && Random.value >  MOVE_STATE_PROBABILITY ){
				this.currentState = STATE_STOPPED;
			}

			// If we're stopping, we should stay stopped for a while
			if( currentState == STATE_STOPPED && Random.value <=  STAY_STATE_PROBABILITY ){
				this.currentState = STATE_STOPPED;
			}
			else if ( currentState == STATE_STOPPED && Random.value >  STAY_STATE_PROBABILITY ){
				this.currentState = STATE_MOVING;
			}
			Timer = 0;

		if( this.currentState == STATE_MOVING ){
			u = !!Mathf.Floor(Random.Range(0,2));
			l = !!Mathf.Floor(Random.Range(0,2));
			d = !!Mathf.Floor(Random.Range(0,2));
			r = !!Mathf.Floor(Random.Range(0,2));
			if (u) {
				transform.position = new Vector3( transform.position.x, transform.position.y + 1, 0);
			}
			if (l) {
				transform.position = new Vector3( transform.position.x-1, transform.position.y, 0);
			}
			if (d) {
				transform.position = new Vector3( transform.position.x, transform.position.y - 1, 0);
			}
			if (r) {
				transform.position = new Vector3( transform.position.x + 1, transform.position.y, 0);
			}
			
			movDirection = u ? 
			(d ? (l ? (r ? 0 : 4) : (r ? 6 : 0)) : (l ? (r ? 2 : 1) : (r ? (l ? 2 : 3) : 2))) : 
			(l ? (r ? (d ? 8 : 0) : (d ? 7 : 4)) : (r ? (d ? 9 : 6) : (d ? 8 : 0)));
			switch (movDirection) {
				case 1:
					transform.localEulerAngles = new Vector3(0,0,45);
					break;
				case 2:
					transform.localEulerAngles = new Vector3(0,0,0);
					break;
				case 3:
					transform.localEulerAngles = new Vector3(0,0,-45);
					break;
				case 4:
					transform.localEulerAngles = new Vector3(0,0,90);
					break;
				case 6:
					transform.localEulerAngles = new Vector3(0,0,-90);
					break;
				case 7:
					transform.localEulerAngles = new Vector3(0,0,135);
					break;
				case 8:
					transform.localEulerAngles = new Vector3(0,0,180);
					break;
				case 9:
					transform.localEulerAngles = new Vector3(0,0,-135);
					break;
				case 0:
					break;
			}
		
		}
	}
}



	function Start () {
		
	}

}