﻿#pragma strict

class SceneMap extends MonoBehaviour {

	var data : Hashtable;
	var genData : Hashtable;
	var newPlayer : GameObject;
	var newNPC : GameObject;

	function LoadData(){
		// Load data
	}
	function SaveData(){
		// save data
	}


	function GeneratePlayer(){

		var playerClone : GameObject = Instantiate( newPlayer, Vector3( 0, 0, 0  ), Quaternion.identity );
		var playerScript : PlayerScript = playerClone.gameObject.GetComponent( PlayerScript );
		playerClone.transform.parent = this.transform;
		genData.Add( "Player", playerScript );
	}

	function GenerateNPCs(){
		for( var i : int = 0; i < 25; i++ ){
			// fixme: don't spawn on top of each other
			var npcClone : GameObject = Instantiate( newNPC, Vector3( Random.Range(-10,10), Random.Range(-10,10), 0  ), Quaternion.identity );
			var npcScript : NPCScript = npcClone.gameObject.GetComponent( NPCScript );
			npcClone.gameObject.name =  "NPC_" + i;
			npcClone.transform.parent = this.transform;
			genData.Add( "NPC_" + i, npcScript );
		}
	}

	function GenerateMeter(){
		//genData.Add( "Meter", new Meter() );
	}
	
	function GenerateMap(){
		//genData.Add( "Map", new Map() );
	}

	function GenerateObjects(){

		// Generate map
		GenerateMap();

		GeneratePlayer();
		
		GenerateNPCs();
		
		GenerateMeter();
	}
	function setParam() {
		this.gameObject.tag = "SceneMap";
	}

	function Start () {
		genData = new Hashtable();
		LoadData();
		setParam();
		GenerateObjects();
	}

	function Update () {

	}
}